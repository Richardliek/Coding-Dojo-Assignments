function addlikes(id){
    document.getElementById(id).innerText++
}